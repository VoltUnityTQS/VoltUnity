export const BASE_URL = '/app/dashboard/default';
export const BASE_TITLE = 'VoltUnity';

export const CONFIG = {
  layout: 'vertical'
};
