const stations = [
  {
    "id": 1,
    "nome": "Esta\u00e7\u00e3o 1",
    "distancia": 1.2,
    "localizacao": "Localiza\u00e7\u00e3o 1"
  },
  {
    "id": 2,
    "nome": "Esta\u00e7\u00e3o 2",
    "distancia": 2.0,
    "localizacao": "Localiza\u00e7\u00e3o 2"
  },
  {
    "id": 3,
    "nome": "Esta\u00e7\u00e3o 3",
    "distancia": 2.8,
    "localizacao": "Localiza\u00e7\u00e3o 3"
  },
  {
    "id": 4,
    "nome": "Esta\u00e7\u00e3o 4",
    "distancia": 3.5,
    "localizacao": "Localiza\u00e7\u00e3o 4"
  },
  {
    "id": 5,
    "nome": "Esta\u00e7\u00e3o 5",
    "distancia": 4.2,
    "localizacao": "Localiza\u00e7\u00e3o 5"
  },
  {
    "id": 6,
    "nome": "Esta\u00e7\u00e3o 6",
    "distancia": 5.0,
    "localizacao": "Localiza\u00e7\u00e3o 6"
  },
  {
    "id": 7,
    "nome": "Esta\u00e7\u00e3o 7",
    "distancia": 5.8,
    "localizacao": "Localiza\u00e7\u00e3o 7"
  },
  {
    "id": 8,
    "nome": "Esta\u00e7\u00e3o 8",
    "distancia": 6.5,
    "localizacao": "Localiza\u00e7\u00e3o 8"
  },
  {
    "id": 9,
    "nome": "Esta\u00e7\u00e3o 9",
    "distancia": 7.2,
    "localizacao": "Localiza\u00e7\u00e3o 9"
  },
  {
    "id": 10,
    "nome": "Esta\u00e7\u00e3o 10",
    "distancia": 8.0,
    "localizacao": "Localiza\u00e7\u00e3o 10"
  }
];

export default stations;