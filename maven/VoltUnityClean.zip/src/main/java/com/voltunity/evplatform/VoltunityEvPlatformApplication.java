package com.voltunity.evplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoltunityEvPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoltunityEvPlatformApplication.class, args);
	}

}
